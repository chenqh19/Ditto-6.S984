#include <linux/module.h>

struct module_memory ml;
