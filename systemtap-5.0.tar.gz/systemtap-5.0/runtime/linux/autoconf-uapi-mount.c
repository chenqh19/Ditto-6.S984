#include <uapi/linux/mount.h>

int foo = MS_RDONLY;
