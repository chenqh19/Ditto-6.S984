#include <linux/uaccess.h>

void foo(void)
{
	user_access_end();
}
